import GlobalError from "../../models/GlobalError";
import { API_URL } from "@/config/apiUrl";

// Custom fetch wrapper
export async function GlobalFetchJson<T>(
  url: string,
  params?: RequestInit,
  base_url?: string
): Promise<T> {
  const fullUrl = `${API_URL}${url}`;

  params = {
    method: params?.method ?? "GET",
    ...params,
  };

  // Only add Content-Type for non-FormData bodies
  const isFormData = params.body instanceof FormData;

  params.headers = {
    ...(isFormData ? {} : { "Content-Type": "application/json" }),
    ...params?.headers,
  };

  try {
    const response = await fetch(fullUrl, params);
    const responseBody = await response.json(); // Only parse once!

    if (!response.ok) {
      console.error("API Error Response:", responseBody);
      throw responseBody as GlobalError;
    }

    console.log("API Success Response:", responseBody);
    return responseBody as T;
  } catch (error) {
    console.error("Fetch error:", error);
    throw error;
  }
}
