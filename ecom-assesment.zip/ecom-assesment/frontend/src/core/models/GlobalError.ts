export default interface GlobalError extends Error {
  error: string;
}
