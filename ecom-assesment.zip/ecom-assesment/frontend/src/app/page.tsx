"use client";

import { useState, useEffect } from "react";
import ProductList from "@/modules/products/components/ProductList/ProductList";
import ProductForm from "@/modules/products/components/ProductForm/ProductForm";
import useGlobalService from "@/core/hook/useGlobalService";
import ProductService from "@/modules/products/services/ProductService";
import { Product, ProductFormData } from "@/modules/products/models/Product";

export default function Home() {
  const productService = useGlobalService(ProductService);
  const [products, setProducts] = useState<Product[]>([]);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedStock, setSelectedStock] = useState("");

  const fetchProducts = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await productService.methods.getProducts();
      setProducts(response.data);
      setAllProducts(response.data);
    } catch (err) {
      setError("Failed to load products. Please try again.");
      console.error("Error fetching products:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    let filtered = allProducts;

    if (selectedCategory) {
      filtered = filtered.filter((p) => p.category === selectedCategory);
    }

    if (selectedStock) {
      filtered = filtered.filter((p) => p.stock_status === selectedStock);
    }

    setProducts(filtered);
  }, [selectedCategory, selectedStock, allProducts]);

  const handleAddProduct = async (data: ProductFormData) => {
    try {
      setIsSubmitting(true);
      setError(null);
      await productService.methods.createProduct(data);
      await fetchProducts();
      setSelectedCategory("");
      setSelectedStock("");
    } catch (err) {
      setError("Failed to add product. Please try again.");
      console.error("Error adding product:", err);
      throw err;
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 dark:bg-gray-950">
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
            Product Management
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Manage your product inventory
          </p>
        </div>

        {error && (
          <div className="mb-6 rounded-lg bg-red-50 p-4 text-red-800 dark:bg-red-900 dark:text-red-200">
            {error}
          </div>
        )}

        <div className="mb-8">
          <ProductForm
            onSubmit={handleAddProduct}
            isSubmitting={isSubmitting}
          />
        </div>

        <div>
          <h2 className="mb-4 text-2xl font-semibold text-gray-900 dark:text-white">
            Product List
          </h2>
          {isLoading ? (
            <div className="flex items-center justify-center rounded-lg border border-gray-200 bg-white p-12 dark:border-gray-700 dark:bg-gray-900">
              <div className="text-center">
                <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-gray-300 border-t-blue-600"></div>
                <p className="mt-4 text-gray-600 dark:text-gray-400">
                  Loading products...
                </p>
              </div>
            </div>
          ) : (
            <ProductList
              products={products}
              onCategoryFilter={setSelectedCategory}
              onStockFilter={setSelectedStock}
              selectedCategory={selectedCategory}
              selectedStock={selectedStock}
            />
          )}
        </div>
      </main>
    </div>
  );
}
