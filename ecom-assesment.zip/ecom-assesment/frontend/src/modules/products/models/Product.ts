export type StockStatus = 'in_stock' | 'out_of_stock' | 'low_stock';

export interface Product {
  id: number;
  name: string;
  price: string | number;
  category: string;
  stock_status: StockStatus;
  created_at?: string;
  updated_at?: string;
}

export interface ProductFormData {
  name: string;
  price: number;
  category: string;
  stock_status: StockStatus;
}

export interface PaginatedProducts {
  current_page: number;
  data: Product[];
  first_page_url: string;
  from: number;
  last_page: number;
  last_page_url: string;
  links: Array<{
    url: string | null;
    label: string;
    page: number | null;
    active: boolean;
  }>;
  next_page_url: string | null;
  path: string;
  per_page: number;
  prev_page_url: string | null;
  to: number;
  total: number;
}

