import GlobalService from "@/core/api/service/GlobalService";
import { GlobalFetchJson } from "@/core/api/fetcher/GlobalFetcher";
import { Product, ProductFormData, PaginatedProducts } from "../models/Product";

export default class ProductService extends GlobalService {
  readonly methods = {
    getProducts: this.getProducts.bind(this),
    createProduct: this.createProduct.bind(this),
    getProduct: this.getProduct.bind(this),
  };

  async getProducts(params?: {
    page?: number;
    per_page?: number;
    category?: string;
    stock_status?: string;
  }): Promise<PaginatedProducts> {
    const queryParams = new URLSearchParams();
    
    if (params?.page) queryParams.append('page', params.page.toString());
    if (params?.per_page) queryParams.append('per_page', params.per_page.toString());
    if (params?.category) queryParams.append('category', params.category);
    if (params?.stock_status) queryParams.append('stock_status', params.stock_status);

    const queryString = queryParams.toString();
    const url = `/products${queryString ? `?${queryString}` : ''}`;

    return GlobalFetchJson<PaginatedProducts>(url);
  }

  async createProduct(data: ProductFormData): Promise<Product> {
    return GlobalFetchJson<Product>('/products', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getProduct(id: number): Promise<Product> {
    return GlobalFetchJson<Product>(`/products/${id}`);
  }
}

