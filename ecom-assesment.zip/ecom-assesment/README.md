# Product Management System

A full-stack product management application built with **Next.js 16** (frontend) and **Laravel 12** (backend).

## 🚀 Quick Start

### Prerequisites
- Node.js 20+
- PHP 8.2+
- Composer
- SQLite

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ecom-assesment
   ```

2. **Backend Setup**
   ```bash
   cd backend
   composer install
   cp .env.example .env
   php artisan key:generate
   php artisan migrate
   php artisan db:seed --class=ProductSeeder
   php artisan serve --port=8001
   ```

3. **Frontend Setup** (in a new terminal)
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

4. **Access the Application**
   - Frontend: http://localhost:3002
   - Backend API: http://localhost:8001/api

## 📋 Features

### Implemented
- ✅ Product listing with responsive table
- ✅ Real-time filtering by category and stock status
- ✅ Add new products with validation
- ✅ Clean, modern UI with dark mode support
- ✅ RESTful API with pagination
- ✅ TypeScript for type safety
- ✅ Tailwind CSS for styling

### API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products` | List all products (with pagination & filtering) |
| POST | `/api/products` | Create new product |
| GET | `/api/products/{id}` | Get single product |
| PUT | `/api/products/{id}` | Update product |
| DELETE | `/api/products/{id}` | Delete product |

## 🏗️ Tech Stack

### Frontend
- **Next.js 16** - React framework with App Router
- **TypeScript** - Type safety
- **Tailwind CSS v4** - Utility-first CSS
- **React 19** - UI library

### Backend
- **Laravel 12** - PHP framework
- **SQLite** - Database (development)
- **Eloquent ORM** - Database abstraction
- **Laravel Sanctum** - API authentication (ready)

## 📁 Project Structure

```
ecom-assesment/
├── frontend/               # Next.js application
│   └── src/
│       ├── app/           # Next.js App Router
│       ├── config/        # Configuration files
│       ├── core/          # Core utilities
│       └── modules/       # Feature modules
│           └── products/  # Product management
├── backend/               # Laravel application
│   ├── app/
│   │   ├── Http/Controllers/
│   │   └── Models/
│   ├── database/
│   │   ├── migrations/
│   │   └── seeders/
│   └── routes/
└── PROJECT_DOCUMENTATION.md  # Detailed documentation
```

## 📖 Documentation

For comprehensive documentation including:
- Architecture overview
- AWS deployment plan
- Team task breakdown
- Future enhancements

Please see [PROJECT_DOCUMENTATION.md](./PROJECT_DOCUMENTATION.md)

## 🧪 Testing

```bash
# Backend tests
cd backend
php artisan test

# Frontend tests
cd frontend
npm run test
```

## 🚢 Deployment

See [PROJECT_DOCUMENTATION.md](./PROJECT_DOCUMENTATION.md) for detailed AWS deployment instructions.

## 📝 License

This project is part of a technical assessment.

## 👤 Author

Technical Assessment Submission for Technical Project Manager Position

