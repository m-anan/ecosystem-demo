<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $products = [
            [
                'name' => 'Laptop Pro 15',
                'price' => 1299.99,
                'category' => 'Electronics',
                'stock_status' => 'in_stock',
            ],
            [
                'name' => 'Wireless Mouse',
                'price' => 29.99,
                'category' => 'Electronics',
                'stock_status' => 'in_stock',
            ],
            [
                'name' => 'Office Chair',
                'price' => 249.99,
                'category' => 'Furniture',
                'stock_status' => 'low_stock',
            ],
            [
                'name' => 'Desk Lamp',
                'price' => 39.99,
                'category' => 'Furniture',
                'stock_status' => 'in_stock',
            ],
            [
                'name' => 'Mechanical Keyboard',
                'price' => 89.99,
                'category' => 'Electronics',
                'stock_status' => 'out_of_stock',
            ],
            [
                'name' => 'Monitor 27"',
                'price' => 349.99,
                'category' => 'Electronics',
                'stock_status' => 'in_stock',
            ],
            [
                'name' => 'Standing Desk',
                'price' => 599.99,
                'category' => 'Furniture',
                'stock_status' => 'in_stock',
            ],
            [
                'name' => 'Webcam HD',
                'price' => 79.99,
                'category' => 'Electronics',
                'stock_status' => 'low_stock',
            ],
        ];

        foreach ($products as $product) {
            Product::create($product);
        }
    }
}
